import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

//Add MappingContext as an additional argument to read or set Headers and properties.

def String customFunc(String arg){
    
  def dateToString = arg.toString()
    //Date inputDate_parsed=new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS").parse(datestr);  

    //DateFormat dateFormat_required = new SimpleDateFormat("mm/dd/yyyy");

    //def converted_datetime=inputDate_parsed//dateFormat_required.format(inputDate_parsed);
    
    return dateToString;
}